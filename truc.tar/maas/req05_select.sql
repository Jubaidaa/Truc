SELECT
    Z."name" AS "zone_name",
    COUNT(DISTINCT H."data_center_id") AS "data_center_count",
    COUNT(H."id") AS "total_servers",
    SUM(H."core_count") AS "total_cores",
    SUM(H."ram") AS "total_ram",
    SUM(H."storage") AS "total_storage"
FROM
    "memorin"."server_hierarchy" AS H
INNER JOIN
    "memorin"."geographic_zones" AS Z ON H."zone_id" = Z."id"
GROUP BY
    Z."name"
ORDER BY
    "data_center_count" DESC,
    "total_servers" DESC,
    "zone_name" ASC;