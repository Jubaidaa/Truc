CREATE OR REPLACE VIEW "memorin"."zoned_devices_logs" AS
SELECT
    L."id",
    L."device_serial",
    L."version_id",
    L."zone_id",
    L."latitude",
    L."longitude",
    L."temperature",
    L."battery_percentage" AS "battery",
    L."signal_strength"
FROM
    "memorin"."device_logs" AS L
WHERE
    L."temperature" BETWEEN 34 AND 45
    AND L."signal_strength" BETWEEN 0 AND 5
    AND L."battery_percentage" BETWEEN 0 AND 100
    
    AND EXISTS 
    (
        SELECT 1 FROM "memorin"."devices" AS D
        WHERE D."serial_number" = L."device_serial"
        AND D."deactivated_at" IS NULL
    )
    
    AND EXISTS 
    (
        SELECT 1 FROM "memorin"."device_versions" AS V
        WHERE V."id" = L."version_id"
    )
    
    AND EXISTS 
    (
        SELECT 1 FROM "memorin"."geographic_zones" AS Z
        WHERE L."zone_id" = Z."id"
        AND L."latitude" BETWEEN Z."min_latitude" AND Z."max_latitude"
        AND L."longitude" BETWEEN Z."min_longitude" AND Z."max_longitude"
    )
WITH CHECK OPTION;