CREATE TEMPORARY VIEW "devices_metrics" AS
SELECT
    L."device_serial" AS "device_serial",
    L."version_id" AS "version_id",
    L."id" AS "log_id",
    L."latitude" AS "lat",
    L."longitude" AS "long",
    L."temperature" AS "temp",
    L."battery_percentage" AS "battery",
    L."signal_strength" AS "signal_strength"
FROM
    "memorin"."devices" AS D,
    "memorin"."device_logs" AS L,
    "memorin"."device_versions" AS V
WHERE
    D."deactivated_at" IS NULL
    AND D."serial_number" = L."device_serial"
    AND L."version_id" = V."id"
ORDER BY
    L."device_serial" ASC,
    V."released_at" DESC,
    L."id" ASC;