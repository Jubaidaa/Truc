INSERT INTO "memorin"."zoned_devices_logs" (
    "device_serial",
    "version_id",
    "zone_id",
    "lat",
    "long",
    "temp",
    "battery",
    "signal_strength"
) VALUES (
    'W4JGVEMW51LE',
    '0.0.0',
    39,
    -12.3,
    0,
    2,
    290,
    12
);
