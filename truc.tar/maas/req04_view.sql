CREATE MATERIALIZED VIEW "memorin"."outdated_devices" AS
WITH "version_ranks" AS (
    SELECT
        V."id",
        V."released_at",
        V."eol_timestamp",
        COUNT(V."released_at") OVER (
            ORDER BY V."released_at" DESC
            ROWS BETWEEN UNBOUNDED PRECEDING AND 1 PRECEDING
        ) 
        AS "versions_behind"
    FROM
        "memorin"."device_versions" AS V
)
SELECT
    D."serial_number",
    D."version_id",
    VR."released_at",
    VR."eol_timestamp",
    VR."versions_behind"
FROM
    "memorin"."devices" AS D
INNER JOIN
    "version_ranks" AS VR ON D."version_id" = VR."id"
WHERE
    D."deactivated_at" IS NULL
    AND VR."versions_behind" > 0;