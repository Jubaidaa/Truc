SELECT
    "serial_number",
    "version_id",
    "released_at",
    "eol_timestamp",
    "versions_behind"
FROM
    "memorin"."outdated_devices"
ORDER BY
    "versions_behind" DESC,
    "serial_number" ASC;