CREATE OR REPLACE VIEW "memorin"."server_hierarchy" AS
WITH RECURSIVE "server_hierarchy_cte" 
(
    "id",
    "zone_id",
    "core_count",
    "ram",
    "storage",
    "master_id",
    "data_center_id"
) 
AS 
(
    SELECT
        S."id",
        S."zone_id",
        S."core_count",
        S."ram",
        S."storage",
        S."master_id",
        S."id" AS "data_center_id"
    FROM
        "memorin"."servers" AS S
    WHERE
        S."master_id" IS NULL
    UNION ALL
    SELECT
        S."id",
        S."zone_id",
        S."core_count",
        S."ram",
        S."storage",
        S."master_id",
        H."data_center_id"
    FROM
        "memorin"."servers" AS S
    INNER JOIN
        "server_hierarchy_cte" AS H ON S."master_id" = H."id"
)
SELECT
    "id",
    "zone_id",
    "core_count",
    "ram",
    "storage",
    "master_id",
    "data_center_id"
FROM
    "server_hierarchy_cte";